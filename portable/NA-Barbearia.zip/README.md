# NA Barbearia portátil para Windows

## Gerar o pacote

Na raiz do projeto, com Node.js LTS/npm e Rust estável instalados, execute:

```powershell
.\portable\Build-Portable.ps1
```

O script instala as dependências JavaScript quando necessário, compila o frontend, compila o backend Rust e monta `portable\release\NA-Barbearia`.

Ele também cria `portable\release\NA-Barbearia-portable.zip`, que pode ser copiado para outro Windows.

## Executar

Abra `Start-NA-Barbearia.cmd`. Ele inicia o backend em segundo plano, usa o SQLite incluído na própria pasta e abre a aplicação no navegador em `http://127.0.0.1:3001`.

Para encerrar o processo, abra `Stop-NA-Barbearia.cmd`.

O conteúdo da pasta `portable\release\NA-Barbearia` é autossuficiente em tempo de execução: o computador de destino não precisa de Node.js, Rust, Cargo, Docker ou um banco separado. O banco fica em `backend\data\nabarbearia.db` e continua na pasta do pacote.

O gerador copia todos os registros da base operacional e também os arquivos WAL/SHM do SQLite quando existirem. Antes de gerar uma nova versão, encerre o backend local para que nenhum registro fique pendente apenas no WAL.

As fotos hospedadas no CDN e o mapa do Google continuam precisando de internet. O sistema, o frontend, a API e o SQLite funcionam localmente.

## Linux

Para gerar o pacote Linux com o frontend, backend, banco e registros incluídos, execute na raiz do projeto:

```powershell
.\portable\Build-Portable-Linux.ps1
```

O resultado fica em `portable\release\NA-Barbearia-linux.tar.gz`. No Linux, extraia o arquivo e execute `bash ./Install-NA-Barbearia.sh`; depois, `bash ./Start-NA-Barbearia.sh`. Esse pacote compila apenas o backend na máquina Linux, usando o frontend já compilado, então Node.js/npm não são necessários no destino.
